const numberFromUser = prompt("Podaj liczbe: ");

if(numberFromUser % 2 == 0)
{
    alert("Liczba jest parzysta")
}
else {
    alert("Liczba jest nieparzysta")
}


const Zamow = document.getElementById("zamow");
const ksztalt = document.getElementById("ksztalt");
const kolor = document.getElementById("kolor");


Zamow.addEventListener("click", function()
{
    const numer = document.getElementById("numer").value;
    
    if(numer == 1)
    {
        ksztalt.innerText = "Wybrany kształt cytryna";
    }
    else if(numer == 2)
    {
        ksztalt.textContent = "lisc";

    }
    else if(numer == 3)
    {
        ksztalt.textContent= "banan";
    }
    else{
        alert("Podano zły numer");    
    }
});

kolor.addEventListener('click', function(){
    const RGB1 = document.getElementById("RGB1").value;
    const RGB2 = document.getElementById("RGB2").value;
    const RGB3 = document.getElementById("RGB3").value;

    const RGB = "rgb(" + RGB1 + "," + RGB2 + "," + RGB3 + ");"
    console.log(RGB);
    kolor.style.backgroundColor = RGB;
    
});

<?php
include 'config.php';

$sql = "SELECT * FROM produkty";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sklep - TrendyWear</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <div class="logo">TrendyWear</div>
        <nav>
            <ul>
                <li><a href="index.html">Home</a></li>
                <li><a href="products.php">Sklep</a></li>
                <li><a href="about.html">O nas</a></li>
                <li><a href="contact.html">Kontakt</a></li>
                <li><a href="cart.html" class="cart">🛒 Koszyk <span id="cart-count">0</span></a></li>
            </ul>
        </nav>
    </header>

    <main>
        <h2>Nasze Produkty</h2>
        <section class="product-list">
            <?php while ($row = $result->fetch_assoc()) { ?>
                <div class="product">
                    <img src="images/<?php echo $row['obrazek']; ?>" alt="<?php echo $row['nazwa']; ?>">
                    <h3><?php echo $row['nazwa']; ?></h3>
                    <p><?php echo $row['opis']; ?></p>
                    <p class="price"><?php echo $row['cena']; ?> zł</p>
                    <button class="add-to-cart">Dodaj do koszyka</button>
                </div>
            <?php } ?>
        </section>
    </main>

    <footer>
        <p>&copy; 2025 TrendyWear - Wszystkie prawa zastrzeżone</p>
    </footer>
</body>
</html>

<?php
$host = "localhost";
$user = "root"; 
$password = ""; 
$database = "baza2";

// Połączenie z bazą
$conn = new mysqli($host, $user, $password, $database);

// Sprawdzenie połączenia
if ($conn->connect_error) {
    die("Błąd połączenia: " . $conn->connect_error);
}

// Pobranie danych z formularza
$imie = $_POST['imie'];
$email = $_POST['email'];
$wiadomosc = $_POST['wiadomosc'];

// Zabezpieczenie przed SQL Injection
$imie = $conn->real_escape_string($imie);
$email = $conn->real_escape_string($email);
$wiadomosc = $conn->real_escape_string($wiadomosc);

// Wstawienie danych do bazy
$sql = "INSERT INTO kontakt (imie, email, wiadomosc) VALUES ('$imie', '$email', '$wiadomosc')";

if ($conn->query($sql) === TRUE) {
    echo "Wiadomość została wysłana!";
} else {
    echo "Błąd: " . $conn->error;
}

// Zamknięcie połączenia
$conn->close();
?>

document.addEventListener("DOMContentLoaded", () => {
    const cartCount = document.getElementById("cart-count");
    const addToCartButtons = document.querySelectorAll(".add-to-cart");
    let cart = JSON.parse(localStorage.getItem("cart")) || [];
    
    const updateCartCount = () => {
        cartCount.textContent = cart.length;
    };
    
    addToCartButtons.forEach(button => {
        button.addEventListener("click", (event) => {
            const name = event.target.dataset.name;
            const price = event.target.dataset.price;
            
            cart.push({ name, price });
            localStorage.setItem("cart", JSON.stringify(cart));
            updateCartCount();
            alert("Dodano do koszyka: " + name);
        });
    });
    
    updateCartCount();
});

<?php
$host = "localhost";
$user = "root"; // Domyślny użytkownik w XAMPP
$password = ""; // Domyślnie brak hasła w XAMPP
$database = "baza2";

$conn = new mysqli($host, $user, $password, $database);

// Sprawdzenie połączenia
if ($conn->connect_error) {
    die("Błąd połączenia: " . $conn->connect_error);
}
?>

<?php
include "db.php";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST["email"];
    $password = $_POST["password"];

    $stmt = $conn->prepare("SELECT * FROM users WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result && $row = $result->fetch_assoc()) {
        if (password_verify($password, $row["password"])) {
            echo "<h2>✅ Udało Ci się zalogować, " . htmlspecialchars($row['username']) . "!</h2>";
        } else {
            echo "<h2>❌ Nieprawidłowe hasło.</h2>";
        }
    } else {
        echo "<h2>❌ Użytkownik o podanym adresie e-mail nie istnieje.</h2>";
    }

    $stmt->close();
    $conn->close();
}
?>

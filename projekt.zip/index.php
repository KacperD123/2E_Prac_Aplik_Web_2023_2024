<?php // Autor: Kacper Dyk ?>
<!DOCTYPE html>
<html lang="pl">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Sklep z Ubraniami</title>
  <link rel="stylesheet" href="style.css" />
</head>
<body>
  
  <header>
    <div class="nav-container">
      <div class="nav-logo">
        <a href="index.html">
          <img src="images/logo.png" alt="Logo Sklepu" />
        </a>
      </div>
      <span class="nav-toggle">☰</span>
      <nav>
        <ul class="nav-menu">
          <li><a href="index.html">Home</a></li>
          <li><a href="products.html">Sklep</a></li>
          <li><a href="about.html">O nas</a></li>
          <li><a href="concact2.html">Kontakt</a></li>
          <li><a href="login.html">Zaloguj się</a></li>
        </ul>
      </nav>
    </div>
  </header>

  
  <section class="banner">
    <div class="banner-content">
      <h1 class="hero-text">Nowa Kolekcja Lato 2025</h1>
      <p>Stylowe ubrania na każdą okazję. Sprawdź nasze bestsellery!</p>
      <a href="products.html" class="btn btn-primary">Zobacz kolekcję</a>
    </div>
  </section>

  
  <section>
    <h2 class="section-title" style="text-align: center;">Polecane Produkty</h2>
    <div class="products-grid">
      <div class="product-card">
        <img src="images/t-shirt.webp" alt="T-shirt klasyczny" />
        <div class="product-info">
          <h3>T-shirt Klasyczny</h3>
          <p>Bawełniany, krój regular, dostępny w różnych kolorach.</p>
          <span class="price">79,00 zł</span>
          <a href="products.html" class="btn">Kup teraz</a>
        </div>
      </div>
      <div class="product-card">
        <img src="images/jeans.webp" alt="Jeansy Slim Fit" />
        <div class="product-info">
          <h3>Jeansy Slim Fit</h3>
          <p>Elastyczne, modny fason, idealne na co dzień.</p>
          <span class="price">199,00 zł</span>
          <a href="products.html" class="btn">Kup teraz</a>
        </div>
      </div>
      <div class="product-card">
        <img src="images/shopping.webp" alt="Sukienka Letnia" />
        <div class="product-info">
          <h3>Sukienka Letnia</h3>
          <p>Zwiewna, kolorowa, lekka tkanina na ciepłe dni.</p>
          <span class="price">149,00 zł</span>
          <a href="products.html" class="btn">Kup teraz</a>
        </div>
      </div>
    
    </div>
  </section>

  
  <footer>
    <div class="footer-container">
      <div class="footer-nav">
        <ul>
          <li><a href="index.html">Home</a></li>
          <li><a href="products.html">Sklep</a></li>
          <li><a href="about.html">O nas</a></li>
          <li><a href="concact2.html">Kontakt</a></li>
        </ul>
      </div>
      <div class="footer-social">
        <a href="#" title="Facebook">Fb</a>
        <a href="#" title="Instagram">Ig</a>
        <a href="#" title="YouTube">Yt</a>
      </div>
      <div class="footer-copy">
        &copy; 2025 Sklep z Ubraniami. Wszelkie prawa zastrzeżone.
      </div>
    </div>
  </footer>

  
  <script>
    const navToggle = document.querySelector('.nav-toggle');
    const navMenu = document.querySelector('.nav-menu');
    navToggle.addEventListener('click', () => {
      navToggle.classList.toggle('active');
      navMenu.classList.toggle('active');
    });
  </script>
</body>
</html>

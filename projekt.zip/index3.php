<?php // Autor: Kacper Dyk ?>
<?php
require 'db.php';

$sql = "SELECT * FROM produkty";
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="pl">
<head>
    <meta charset="UTF-8">
    <title>Sklep</title>
</head>
<body>
    <h1>Produkty</h1>
    <ul>
        <?php while($row = $result->fetch_assoc()): ?>
            <li>
                <h3><?= htmlspecialchars($row['nazwa']) ?></h3>
                <p><?= htmlspecialchars($row['opis']) ?></p>
                <strong><?= number_format($row['cena'], 2) ?> zł</strong><br>
                <?php if ($row['obrazek']): ?>
                    <img src="img/<?= htmlspecialchars($row['obrazek']) ?>" alt="<?= $row['nazwa'] ?>" width="200">
                <?php endif; ?>
            </li>
        <?php endwhile; ?>
    </ul>
</body>
</html>

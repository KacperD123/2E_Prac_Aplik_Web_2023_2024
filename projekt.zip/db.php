<?php // Autor: Kacper Dyk ?>
<?php
$host = 'localhost';
$user = 'root';     
$pass = '';         
$db   = 'baza2';    

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Błąd połączenia z bazą danych: " . $conn->connect_error);
}
?>

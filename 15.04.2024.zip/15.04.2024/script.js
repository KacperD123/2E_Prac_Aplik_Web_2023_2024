let tekst = prompt("Wprowadź tekst: ");

function reverseTekst(){0
    tekst.reverse().join('');
    return tekst;
}

alert(tekst);



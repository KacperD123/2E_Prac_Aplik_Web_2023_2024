<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <script>

      /*
      let celsjusze = prompt("Daj celsjuesze");
      f = celsjusze * 9/5 + 32;
      document.write("tempertarura w F = "+ f + </br>"");
      */


      /*
      let firstNumber = prompt("podaj pierwsza liczbe");
      let secondNumber = prompt("podaj druga liczbe");
 
      document.write(firstNumber + "+" + secondNumber + "=" + (parseInt(firstNumber) + parseInt(secondNumber)) + "</br>");
      document.write(firstNumber + "-" + secondNumber + "=" + (parseInt(firstNumber) - parseInt(secondNumber)) + "</br>");
      document.write(firstNumber + "/" + secondNumber + "=" + (parseInt(firstNumber) / parseInt(secondNumber)) + "</br>");
      document.write(firstNumber + "*" + secondNumber + "=" + (parseInt(firstNumber) * parseInt(secondNumber)) + "</br>");
      */


      //zadanie 3
      /*
      const Pi = 3.14159;
      let r = prompt("podaj promien: ");
      let poleKola = 2 * Pi * r;
      poleKola = poleKola.toFixed(2);
      document.write("Pola koła wynosi:" + poleKola);
      */

      //zadanie 4

      let wiek = prompt("podaj wiek: ");
      let wiekNaDni = wiek * 365;
      document.write("twoj wiek w dniach: " + wiekNaDni);
      </script>

    <?php

    //zadanie 1
    /*
    $c = 10.5;
    $f =  $c * 9/5 + 32;
    echo "Celsjuesze a F = $f";
    */


    //zadanie 2

    /*
    $number1 = 4;
    $number2 = 5;


    $dodawanie = "+";
    $odejmowanie = "-";
    $mnozenie = "*";
    $dzielenie = "/";

    echo ("$number1 $dodawanie $number2 = ". $number1 + $number2. "<br>");
    echo ("$number1 $odejmowanie $number2 = ". $number1 - $number2. "<br>");
    echo ("$number1 $mnozenie $number2 = ". $number1 * $number2. "<br>");
    echo ("$number1 $dzielenie $number2 = ". $number1 / $number2. "<br>");

    */
    //zadanie 3
    /*
    $r = 5;
    $pi = 3.14159;
    $poleKola = $r * $pi * 2;
    $poleKola = round($poleKola, 2);
    echo("Pole kola" . $poleKola);
    */
    
    // zadanie 4
    
    $ilosc_lat = 4;
    $wiek_na_dni = $ilosc_lat * 365;
    echo ("wiek w dniach: ". $wiek_na_dni) 
    
    ?>

    
</body>
</html>
<?php
$host = 'localhost';
$user = 'root';     // XAMPP: domyślny użytkownik
$pass = '';         // brak hasła
$db   = 'baza2';    // Twoja baza

$conn = new mysqli($host, $user, $pass, $db);

if ($conn->connect_error) {
    die("Błąd połączenia z bazą danych: " . $conn->connect_error);
}
?>

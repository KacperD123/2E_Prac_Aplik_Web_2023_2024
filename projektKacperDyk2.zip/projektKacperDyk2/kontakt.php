<?php
require 'db.php';

$imie = $_POST['imie'];
$email = $_POST['email'];
$wiadomosc = $_POST['wiadomosc'];

$sql = "INSERT INTO kontakt (imie, email, wiadomosc) VALUES (?, ?, ?)";
$stmt = $conn->prepare($sql);
$stmt->bind_param("sss", $imie, $email, $wiadomosc);

if ($stmt->execute()) {
    echo "Dziękujemy za wiadomość!";
} else {
    echo "Błąd: " . $stmt->error;
}

$conn->close();
?>
